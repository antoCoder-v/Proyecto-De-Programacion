package com.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        Pane root = new Pane();

        // LED apagado (gris)
        Ellipse ledOffTop = new Ellipse(100, 90, 20, 15);
        ledOffTop.setStroke(Color.BLACK);
        ledOffTop.setFill(Color.DARKGRAY);
        ledOffTop.setStrokeWidth(2);

        Rectangle ledOffBottom = new Rectangle(80, 90, 40, 15);
        ledOffBottom.setStroke(Color.BLACK);
        ledOffBottom.setFill(Color.DARKGRAY);
        ledOffBottom.setStrokeWidth(2);

        // LED encendido (rojo)
        Ellipse ledOnTop = new Ellipse(200, 90, 20, 15);
        ledOnTop.setStroke(Color.BLACK);
        ledOnTop.setFill(Color.RED);
        ledOnTop.setStrokeWidth(2);

        Rectangle ledOnBottom = new Rectangle(180, 90, 40, 15);
        ledOnBottom.setStroke(Color.BLACK);
        ledOnBottom.setFill(Color.RED);
        ledOnBottom.setStrokeWidth(2);

        // Patas del LED apagado
        Line ledOffLeg1 = new Line(90, 105, 90, 145); // Patilla larga
        ledOffLeg1.setStroke(Color.BLACK);
        ledOffLeg1.setStrokeWidth(2);

        Line ledOffLeg2 = new Line(110, 105, 110, 130); // Patilla corta
        ledOffLeg2.setStroke(Color.BLACK);
        ledOffLeg2.setStrokeWidth(2);

        // Patas del LED encendido
        Line ledOnLeg1 = new Line(190, 105, 190, 145); // Patilla larga
        ledOnLeg1.setStroke(Color.BLACK);
        ledOnLeg1.setStrokeWidth(2);

        Line ledOnLeg2 = new Line(210, 105, 210, 130); // Patilla corta
        ledOnLeg2.setStroke(Color.BLACK);
        ledOnLeg2.setStrokeWidth(2);

        // Agregar todos los componentes al contenedor
        root.getChildren().addAll(ledOffTop, ledOffBottom, ledOffLeg1, ledOffLeg2,
                                  ledOnTop, ledOnBottom, ledOnLeg1, ledOnLeg2);

        Scene scene = new Scene(root, 300, 200);
        primaryStage.setTitle("LEDs en JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}