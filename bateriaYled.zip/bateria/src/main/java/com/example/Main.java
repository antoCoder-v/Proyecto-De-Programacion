package com.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        Pane root = new Pane();

        // Parte superior dorada de la batería
        Rectangle topPart = new Rectangle(100, 50, 100, 60);
        topPart.setStroke(Color.BLACK);
        topPart.setFill(Color.ORANGE);
        topPart.setStrokeWidth(3);

        // Parte inferior negra de la batería
        Rectangle bottomPart = new Rectangle(100, 110, 100, 90);
        bottomPart.setStroke(Color.BLACK);
        bottomPart.setFill(Color.BLACK);
        bottomPart.setStrokeWidth(3);

        // Terminal positivo (Círculo pequeño)
        Circle positiveTerminal = new Circle(125, 45, 10);
        positiveTerminal.setStroke(Color.BLACK);
        positiveTerminal.setFill(Color.SILVER);
        positiveTerminal.setStrokeWidth(2);

        // Terminal negativo (Círculo grande)
        Circle negativeTerminalOuter = new Circle(175, 45, 15);
        negativeTerminalOuter.setStroke(Color.BLACK);
        negativeTerminalOuter.setFill(Color.SILVER);
        negativeTerminalOuter.setStrokeWidth(2);

        Circle negativeTerminalInner = new Circle(175, 45, 8);
        negativeTerminalInner.setStroke(Color.BLACK);
        negativeTerminalInner.setFill(Color.LIGHTGRAY);
        negativeTerminalInner.setStrokeWidth(2);

        // Agregar las formas al contenedor
        root.getChildren().addAll(bottomPart, topPart, positiveTerminal, negativeTerminalOuter, negativeTerminalInner);

        Scene scene = new Scene(root, 300, 250);
        primaryStage.setTitle("Batería de 9V en JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}