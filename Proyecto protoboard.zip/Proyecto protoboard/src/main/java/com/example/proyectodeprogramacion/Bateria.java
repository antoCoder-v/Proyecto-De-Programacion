package com.example.proyectodeprogramacion;

public class Bateria{
    
}